from django.contrib import admin

from .models import Flat


admin.site.register(Flat)
